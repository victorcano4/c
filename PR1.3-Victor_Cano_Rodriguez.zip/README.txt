A la carpeta "llibreria random" estan las llibrerias de numeros aleatoris que vau proporcionar al moodle que son necessaries per a que funcionin les 2 llistes. 

A la carpeta "Informe,arxius csv i excel comparatiu" està tot lo dit al nom. El excel comparatiu conté un excel amb la gràfica de les dues llistes i una conjunta en un arxiu .xlsx. També conté les taules dels resultats.

A les altres dues carpetes hi ha els arxius font.