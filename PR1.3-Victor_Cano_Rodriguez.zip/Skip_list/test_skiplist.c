#include "skiplist.h"

int main()
{
	
	int i=0, d=0;
	bool b = false;
	skip_list sl;
	long seed1, seed2;
	phrtsd("fakdhfakfhalksfh", &seed1, &seed2);
	setall(seed1, seed2);
	Crear(&sl);
	printf("La skip list ha estat testejada anteriorment\n");
	printf("\nPassem ara a generar un fitxer csv amb el resultat de cerques de numeros aleatoris:\n");

	FILE* fp;
	fp = fopen("resultados_sl.csv", "w+");
	Crear(&sl);
	int cost, costtotal = 0;
	long num;
	long largest,temparray[1000];
	fprintf(fp, "Mida de la llista,Cost mitja,Desviacio estandar");
	for (int j = 1; j <= 50; j++)
	{
		for (int k = 0; k < j * 1000; k++)
		{
			Inserir(&sl, ignuin(1, j * 2000));
			//printf("%d ",k);
		}
		for (int i = 0; i < 1000; i++)
		{
			Cost_Buscar(sl, ignuin(1, j * 2000), &cost);
			costtotal = costtotal + cost;
			temparray[i] = cost;
		}
		costtotal = costtotal / 1000;	//calcul de la mitja
		for (int i = 0; i < 1000; i++)
		{
			d = d + ((temparray[i] - costtotal) * (temparray[i] - costtotal));
		}
		d = d / 1000;
		d = sqrt(d);
		fprintf(fp, "\n%d,%d,%d", j * 1000, costtotal,d);
		d = 0;
		Destruir(&sl);
		Crear(&sl);
		//printf("%d ", j);
	}
	fclose(fp);

	
}