#include "skiplist.h"

int Crear(skip_list* sl)
{
	sl->head = (node*)malloc(sizeof(node));
	sl->head->element = NULL;
	sl->head->anterior= (node*)malloc(sizeof(node));
	sl->head->anterior = NULL;
	sl->head->seguent= (node*)malloc(sizeof(node));
	sl->head->seguent = NULL;
	sl->head->dalt = (node*)malloc(sizeof(node));
	sl->head->dalt = NULL;
	sl->head->baix = (node*)malloc(sizeof(node));
	sl->head->baix = NULL;
	sl->nivells = 1;
	return SUCCESS;
}
int Destruir(skip_list* sl)
{
	node * n,* temp;
	n = (node*)malloc(sizeof(node));
	temp = (node*)malloc(sizeof(node));
	n = sl->head;
	while (n->baix != NULL)
	{
		n = n->baix;
	}
	while (n->seguent != NULL)
	{
		temp = n;
		n = n->seguent;
		free(temp);
	}
	sl->head->seguent = NULL;
	sl->head->dalt = NULL;
	sl->head->anterior = NULL;
	sl->head->baix = NULL;
}
int Inserir(skip_list* sl, int elem) 
{
	int i, j = 0, k = 1;
	bool final = false, cara;
	node* n, * n2, * n3, * n4, * n5;
	n = (node*)malloc(sizeof(node));
	n2 = (node*)malloc(sizeof(node));
	n3 = (node*)malloc(sizeof(node));
	n2->element = elem;
	n3->element = elem;
	n = sl->head;
	while (final == false)
	{
		if (n->seguent != NULL)	//primero miramos a la derecha
		{
			if (n->seguent->element<=elem)
			{
				if (n->seguent->element == elem)
				{
					while (n->baix != NULL)
					{
						n = n->baix;
					}
					//INSERCI� D'UN N�MERO REPETIT
					if (n->seguent != NULL)
						n->seguent->anterior = n2;
					n2->seguent = n->seguent;
					n->seguent = n2;
					n2->anterior = n;
					n2->baix = NULL;
					n2->dalt = NULL;
					n2->element = elem;
					i = ignuin(0, 1);
					while (i == 1)
					{
						n2->dalt = (node*)malloc(sizeof(node));
						n2->dalt->baix = n2;
						n2 = n2->dalt;
						//INCREMENTAR NIVEL DE HEAD SI ES M�S BAJO Q ESTE
						k++;
						if (k > sl->nivells)
						{
							sl->head->dalt = (node*)malloc(sizeof(node));
							sl->head->dalt->baix = sl->head;
							sl->head = sl->head->dalt;
							sl->head->dalt = NULL;
							sl->head->anterior = NULL;
							sl->head->seguent = NULL;
							sl->nivells++;
						}
						while (n->dalt == NULL)
						{
							//buscar anterior columna de misma altura
							n = n->anterior;
						}
						n = n->dalt;
						//una vez tenemos otra columna de la misma altura la conectamos a la nueva
						if(n->seguent!=NULL)
							n->seguent->anterior = n2;
						n2->seguent = n->seguent;
						n->seguent = n2;
						n2->anterior = n;
						n2->dalt = NULL;
						n2->element = elem;
						i = ignuin(0, 1);
					}
					k = 1;
					final = true;
				}
				else
				{
					//EL SIGUIENTE N�MERO ES M�S PEQUE�O, POR TANTO SEGUIMOS BUSCANDO
					n = n->seguent;
				}
			}
			else
			{
				//EL N�MERO SIGUIENTE ES M�S GRANDE
				if (n->baix == NULL)
				{
					//el n�mero siguiente es m�s grande y estamos abajo de todo por tanto inserci�n delante de n
					if (n->seguent != NULL)
						n->seguent->anterior = n2;
					n2->seguent = n->seguent;
					n->seguent = n2;
					n2->anterior = n;
					n2->baix = NULL;
					n2->dalt = NULL;
					n2->element = elem;
					i = ignuin(0, 1);
					while (i == 1)
					{
						n2->dalt = (node*)malloc(sizeof(node));
						n2->dalt->baix = n2;
						n2 = n2->dalt;
						//INCREMENTAR NIVEL DE HEAD SI ES M�S BAJO Q ESTE
						k++;
						if (k > sl->nivells)
						{
							sl->head->dalt = (node*)malloc(sizeof(node));
							sl->head->dalt->baix = sl->head;
							sl->head = sl->head->dalt;
							sl->head->dalt = NULL;
							sl->head->anterior = NULL;
							sl->head->seguent = NULL;
							sl->nivells++;
						}
						while (n->dalt == NULL)
						{
							//buscar anterior columna de misma altura
							n = n->anterior;
						}
						n = n->dalt;
						//una vez tenemos otra columna de la misma altura la conectamos a la nueva
						if (n->seguent != NULL)
							n->seguent->anterior = n2;
						n2->seguent = n->seguent;
						n->seguent = n2;
						n2->anterior = n;
						n2->dalt = NULL;
						n2->element = elem;
						i = ignuin(0, 1);

					}
					k = 1;
					final = true;
				}
				else
				{
					//el numero siguiente es mayor pero abajo no es nulo, por tanto bajamos
					n = n->baix;
				}
			}
			


		}
		else
		{
			if (n->baix != NULL)	//si la derecha es NULL miramos abajo
			{
				n = n->baix;		//si abajo no es NULL miramos a la derecha del de abajo
			}
			else	//inserci�n al final
			{
				n2->seguent = NULL;
				n->seguent = n2;
				n2->anterior = n;
				n2->baix = NULL;
				n2->dalt = NULL;
				n2->element = elem;
				i = ignuin(0, 1);
				while (i == 1)
				{
					n2->dalt = (node*)malloc(sizeof(node));
					n2->dalt->baix = n2;
					n2 = n2->dalt;
					//INCREMENTAR NIVEL DE HEAD SI ES M�S BAJO Q ESTE
					k++;
					if (k > sl->nivells)
					{
						sl->head->dalt = (node*)malloc(sizeof(node));
						sl->head->dalt->baix = sl->head;
						sl->head = sl->head->dalt;
						sl->head->dalt = NULL;
						sl->head->anterior = NULL;
						sl->head->seguent = NULL;
						sl->nivells++;
					}
					while (n->dalt == NULL)	//aqui
					{
						//buscar anterior columna de misma altura
						n = n->anterior;
					}
					n = n->dalt;
					//una vez tenemos otra columna de la misma altura la conectamos a la nueva
					n2->seguent = NULL;
					n->seguent = n2;
					n2->anterior = n;
					n2->dalt = NULL;
					n2->element = elem;
					i = ignuin(0, 1);
				}
				k = 1;
				final = true;
			}
				
		}
	}
	/*
	//COMPROBAR SI TODO EST� BIEN CON 6 INSERCIONES Y PROBAR A INSERTAR X EL MEDIO
	int i, j = 0, k = 1;
	bool final=false, cara;
	node* n, * n2,* n3,* n4,* n5;
	n= (node*)malloc(sizeof(node));
	n2 = (node*)malloc(sizeof(node));
	n3= (node*)malloc(sizeof(node));
	n2->element = elem;
	n3->element = elem;
	n = sl->head;
	while (final == false)
	{
		j = 0;
		if (n->seguent != NULL)
		{
			if (n->seguent->element > elem)
			{
				//n = n->seguent;
				while (n->baix != NULL)
				{
					n = n->baix;
				}
				n->seguent->anterior = n2;	//n->seguent=null;
				n2->seguent = n->seguent;
				n->seguent = n2;
				n2->anterior = n;
				n2->baix= (node*)malloc(sizeof(node));
				n2->baix = NULL;
				cara = false;
				i=ignuin(0, 1);
				if (i == 1)
					cara = true;
				else
				{
					cara = false;
					if ((i != 1) && (i != 0))
						return ERROR_ALEATORI;
				}
				while (cara == true)
				{
					//INCREMENTAR NIVEL DE HEAD SI ES M�S BAJO Q ESTE
					k++;
					if (k > sl->nivells)
					{
						sl->head->dalt = (node*)malloc(sizeof(node));
						sl->head->dalt->baix = sl->head;
						sl->head = sl->head->dalt;
						sl->head->dalt = NULL;
						sl->head->anterior = NULL;
						sl->head->seguent = NULL;
						sl->nivells++;
					}
					n2->dalt= (node*)malloc(sizeof(node));
					n2->dalt->baix = n2;
					n2 = n2->dalt;
					n2->element = elem;
					if (n->dalt != NULL)
					{
						n2->anterior = n;
						n2->seguent = n->seguent;
						n->seguent->anterior = n2;
						n->seguent = n2;
						n2->dalt = NULL;
					}
					else
					{
						while ((n->dalt == NULL)&&(n->anterior!=NULL))
						{
							if (n->anterior != NULL)
								n = n->anterior;
						}
						n = n->dalt;
						n2->anterior = n;
						n->seguent->anterior = n2;
						n2->seguent = n->seguent;
						n->seguent = n2;
					}
					i = ignuin(0, 1);
					if (i == 1)
						cara = true;
					else
						cara = false;
					j++;
				}
				final = true;
					
			}
			else
			{
				n = n->seguent;
			}
		}
		else
		{
			if (n->baix != NULL)
			{
				n = n->baix;
			}
			else
			{
				n3->anterior = n;
				n3->seguent = n->seguent;
				if (n->seguent != NULL)
					n->seguent->anterior = n3;
				n->seguent = n3;
				n3->baix = (node*)malloc(sizeof(node));;
				n3->baix = NULL;
				cara = false;
				i = ignuin(0, 1);
				if (i == 1)
					cara = true;
				else
				{
					cara = false;
					if ((i != 1) && (i != 0))
						return ERROR_ALEATORI;
					n3->dalt = NULL;
				}
				while (cara == true)
				{
					k++;
					//secci� per incrementar nivells el element null del principi
					if (k > sl->nivells)
					{
						sl->head->dalt = (node*)malloc(sizeof(node));
						sl->head->dalt->baix = sl->head;
						sl->head = sl->head->dalt;
						sl->head->dalt = NULL;
						sl->head->anterior = NULL;
						sl->head->seguent = NULL;
						sl->nivells++;
					}
					n3->dalt = (node*)malloc(sizeof(node));
					n3->dalt->baix = n3;
					n3 = n3->dalt;
					n3->element = elem;
					if (n->dalt != NULL)
					{
						n = n->dalt;
						n3->anterior = n;
						n3->seguent = n->seguent;
						if (n->seguent != NULL)
							n->seguent->anterior = n3;
						n->seguent = n3;
						n3->dalt = NULL;
					}
					else
					{
						while (n->dalt == NULL)
						{
							n = n->anterior;
						}
						n = n->dalt;
						n3->anterior = n;
						n3->seguent = n->seguent;
						if (n->seguent != NULL)
							n->seguent->anterior = n3;
						n->seguent = n3;
						n3->dalt = NULL;
					}
					i = ignuin(0, 1);
					if (i == 1)
						cara = true;
					else
						cara = false;
					j++;
				}
				final = true;
			}
		}
	}
	return SUCCESS;
*/}
int Esborrar(skip_list* sl, int elem)
{
	int i;
	node* n,* n2;
	bool final,f=false;
	n = (node*)malloc(sizeof(node));
	n2 = (node*)malloc(sizeof(node));
	n = sl->head;
	final = false;
	while (final == false)
	{
		if (n->seguent != NULL)
		{
			if (n->seguent->element == elem)
			{
				n2 = n->seguent;
				while (n2->baix != NULL)
				{
					n = n2->anterior;
					if (n2->seguent == NULL)
					{
						n->seguent = NULL;
					}
					else
					{
						n->seguent = n2->seguent;
						n2->seguent->anterior = n;
					}
					n2 = n2->baix;
				}
				n = n2->anterior;
				if (n2->seguent == NULL)
				{
					n->seguent = NULL;
				}
				else
				{
					n->seguent = n2->seguent;
					n2->seguent->anterior = n;
				}
				final = true;
			}
			else
			{
				if (n->seguent->element > elem)
				{
					n = n->baix;
				}
				else
				{
					if (n->seguent->element <= elem)
					{
						n = n->seguent;
					}
				}
			}
		}
		else
		{
			if (n->baix)
				return NO_TROBAT_ESBORRAR;
			n = n->baix;
		}
	}


	return SUCCESS;
}
int Longitud(skip_list sl, int* lon)
{
	node* n;
	int i = 0;
	n = (node*)malloc(sizeof(node));
	n = sl.head;
	while (n->baix != NULL)
	{
		n = n->baix;
	}
	while (n->seguent != NULL)
	{
		i++;
		n = n->seguent;
	}
	*lon = i;
	return SUCCESS;
}
int Buscar(skip_list sl, int elem, bool* trobat)
{
	int i;
	node* n;
	bool final;
	n = (node*)malloc(sizeof(node));
	n = sl.head;
	*trobat = false;
	final = false;
	while ((final == false) && ((n->seguent != NULL) || (n->baix != NULL)))
	{
		if (n->seguent != NULL)
		{
			if (n->seguent->element == elem)
			{
				final = true;
				*trobat = true;
			}
			else
			{
				if (n->seguent->element < elem)
				{
					n = n->seguent;
				}
				else
				{
					if (n->baix != NULL)
					{
						n = n->baix;
					}
					else
					{
						final = true;
					}
				}
			}

		}
		else
		{
			if (n->baix != NULL)
			{
				n = n->baix;
			}
			else
			{
				final = true;
			}
		}
	}
	return SUCCESS;
}
int Cost_Buscar(skip_list sl, int elem, int* cost)
{
	int i=0;
	node* n;
	bool final;
	n = (node*)malloc(sizeof(node));
	n = sl.head;
	final = false;
	while ((final == false) && ((n->seguent != NULL) || (n->baix != NULL)))
	{
		if (n->seguent != NULL)
		{
			if (n->seguent->element == elem)
			{
				final = true;
			}
			else
			{
				if (n->seguent->element < elem)
				{
					n = n->seguent;
				}
				else
				{
					if (n->baix != NULL)
					{
						n = n->baix;
					}
					else
					{
						final = true;
					}
				}
			}

		}
		else
		{
			if (n->baix != NULL)
			{
				n = n->baix;
			}
			else
			{
				final = true;
			}
		}
		i++;
	}
	*cost = i;
	return SUCCESS;
}
