#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "random.h"
#include <math.h>

#define SUCCESS 0
#define ERROR_CREAR 1
#define ERROR_DESTRUIR 2
#define LLISTA_NO_CREADA 3
#define ERROR_ALEATORI 4
#define NO_TROBAT_ESBORRAR 5

typedef struct node node;
struct node
{
	int element;
	node* anterior;
	node* seguent;
	node* dalt;
	node* baix;

};

typedef struct skip_list skip_list;
struct skip_list
{
	node* head;
	int nivells;
};
int Crear(skip_list* sl);
int Destruir(skip_list* sl);
int Inserir(skip_list* sl, int elem);
int Esborrar(skip_list* sl, int elem);
int Longitud(skip_list sl, int* lon);
int Buscar(skip_list sl, int elem, bool* trobat);
int Cost_Buscar(skip_list sl, int elem, int* cost); 
