#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h> 
#include <math.h>

#define SUCCESS 0
#define ERROR_CREAR 1
#define ERROR_DESTRUIR 2
#define LLISTA_NO_CREADA 3
#define LLISTA_BUIDA 4
#define LLISTA_PLENA 5
#define PDI_AL_FINAL 6
#define PDI_AL_PRINCIPI 6

typedef struct node node;
struct node
{
	int element;
	node * anterior;
	node * seguent;

}; 

typedef struct llista_encadenada llista_encadenada;
struct llista_encadenada
{
	node * pdi;
}; 

int Crear(llista_encadenada* ll);
int Destruir(llista_encadenada* ll);
int Principi(llista_encadenada* ll);
int Final(llista_encadenada* ll);
int Avancar(llista_encadenada* ll);
int Retrocedir(llista_encadenada* ll);
int Es_Final(llista_encadenada ll, bool* esfinal);
int Actual(llista_encadenada ll, int* elem);
int Inserir(llista_encadenada* ll, int elem);
int Esborrar(llista_encadenada* ll);
int Longitud(llista_encadenada ll, int* lon);
int Buscar(llista_encadenada ll, int elem, bool* trobat);
int Cost_Buscar(llista_encadenada ll, int elem, int* cost);
