#include "lista.h"
int Crear(llista_encadenada* ll)
{
	if (ll == NULL)
	{
		return ERROR_CREAR;
	}
	ll->pdi = 0;
	node * n ;
	n = (node*)malloc(sizeof(node));
	/*
	n->anterior = NULL;
	n->seguent = NULL;
	ll->pdi = n;
	*/
	ll->pdi = NULL;
	return SUCCESS;
}

int Destruir(llista_encadenada* ll)
{
	if (ll == NULL)
		return LLISTA_NO_CREADA;
	else
	{
		node* temp;
		bool b;
		Principi(ll);
		Es_Final(*ll, &b);
		while (b==false)
		{
			temp = ll->pdi;
			Avancar(ll);
			free(temp);
			Es_Final(*ll, &b);
		}
		temp = ll->pdi;
		free(temp);
	}
	return SUCCESS;
}

int Principi(llista_encadenada* ll)
{
	if (ll->pdi == NULL)
		return LLISTA_NO_CREADA;
	if(ll->pdi->anterior==NULL)
		return SUCCESS;
	else
	{
		while (ll->pdi->anterior != NULL)
		{
			ll->pdi = ll->pdi->anterior;
		}
		return SUCCESS;
	}
}

int Final(llista_encadenada* ll)
{
	if (ll == NULL)
		return LLISTA_NO_CREADA;
	int i = 0;
	while (ll->pdi->seguent != NULL)
	{
		ll->pdi = ll->pdi->seguent;
	}
	return SUCCESS;
}

int Avancar(llista_encadenada* ll)
{
	if (ll == NULL)
		return LLISTA_NO_CREADA;
	bool b;
	Es_Final(*ll, &b);
	if (b == true)
		return PDI_AL_FINAL;
	ll->pdi = ll->pdi->seguent;
	return SUCCESS;
}

int Retrocedir(llista_encadenada* ll)
{
	if (ll == NULL)
		return LLISTA_NO_CREADA;
	if (ll->pdi->anterior==NULL)
		return PDI_AL_PRINCIPI;
	ll->pdi = ll->pdi->anterior;
	return SUCCESS;
}

int Es_Final(llista_encadenada ll, bool* esfinal)
{
	if (ll.pdi == NULL)
		return LLISTA_NO_CREADA;
	if (ll.pdi->seguent == NULL)
	{
		*esfinal = true;
		return SUCCESS;
	}
	*esfinal = false;
	return SUCCESS;
}

int Actual(llista_encadenada ll, int* elem)
{
	if (&ll == NULL)
		return LLISTA_NO_CREADA;
	*elem=ll.pdi->element;
	return SUCCESS;
}

int Inserir(llista_encadenada* ll, int elem)
{
	if (&ll == NULL)
		return LLISTA_NO_CREADA;
	if (ll->pdi == NULL)
	{
		ll->pdi = (node*)malloc(sizeof(node));
		ll->pdi->anterior = NULL;
		ll->pdi->seguent = NULL;
		ll->pdi->element = elem;
		return SUCCESS;
	}
	else
	{
		node* n, aux;
		n = (node*)malloc(sizeof(node));
		n->element = elem;
		n->seguent = ll->pdi->seguent;
		n->anterior = ll->pdi;
		if(ll->pdi->seguent!=NULL)
			ll->pdi->seguent->anterior = n;
		ll->pdi->seguent = n;
		return SUCCESS;
	}
}

int Esborrar(llista_encadenada* ll)
{
	if (ll->pdi == NULL)
		return LLISTA_BUIDA;
	node * noupdi;
	noupdi = (node*)malloc(sizeof(node));
	if (ll->pdi->seguent == NULL)
		noupdi = ll->pdi->anterior;
	else
		noupdi = ll->pdi->seguent;
	if (ll->pdi->anterior != NULL)
		ll->pdi->anterior->seguent = ll->pdi->seguent;
	if(ll->pdi->seguent!=NULL)
		ll->pdi->seguent->anterior = ll->pdi->anterior;
	free(ll->pdi);
	ll->pdi= (node*)malloc(sizeof(node));
	ll->pdi = noupdi;
	return SUCCESS;
}

int Longitud(llista_encadenada ll, int* lon)
{
	int i=1;
	bool b;
	if (&ll == NULL)
	{
		return LLISTA_NO_CREADA;
	}
	if (ll.pdi == NULL)
	{
		*lon = 0;
		return SUCCESS;
	}
	Principi(&ll);
	Es_Final(ll, &b);
	while (b == false)
	{
		i++;
		Avancar(&ll);
		Es_Final(ll, &b);
	}
	*lon = i;
	return SUCCESS;
}

int Buscar(llista_encadenada ll, int elem, bool* trobat)
{
	if (ll.pdi == NULL)
		return LLISTA_NO_CREADA;
	Principi(&ll);
	*trobat = false;
	int i = 0,e;
	bool final = false;
	while (final == false)
	{
		Actual(ll, &e);
		if (e == elem)
		{
			final = true;
			*trobat = true;
		}
		Es_Final(ll, &final);
		Avancar(&ll);
	}
	return SUCCESS;
}

int Cost_Buscar(llista_encadenada ll, int elem, int* cost)
{
	if (ll.pdi == NULL)
		return LLISTA_NO_CREADA;
	Principi(&ll);
	*cost = 0;
	int e;
	bool final = false;
	while (final == false)
	{
		Actual(ll, &e);
		if (e == elem)
			final = true;
		if (final == false)
		{
			Es_Final(ll, &final);
			if(final==true)
				*cost = *cost + 1;
		}
		if(final==false)
			Avancar(&ll);
		*cost=*cost+1;
	}
	return SUCCESS;
}
