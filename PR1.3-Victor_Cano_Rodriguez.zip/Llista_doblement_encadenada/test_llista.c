#include "lista.h"

int main()
{
	int success, p;
	long d = 0;
	llista_encadenada l;
	printf("Prova de la funcio Crear\n");
	success=Crear(&l);
	if (success != SUCCESS)
		printf("Error al crear");
	printf("Funciona correctament\n");

	/*bool b;
	Es_Final(l, &b);
	if (b == true)
		printf("funchiona :)");*/
	bool b = true, busca;
	Inserir(&l, 1);
	Actual(l, &p);
	if (p != 1)
		b = false;
	Inserir(&l, 2);
	Avancar(&l);
	Actual(l, &p);
	if (p != 2)
		b = false;
	Inserir(&l, 3);
	Avancar(&l);
	Actual(l, &p);
	if (p != 3)
		b = false;
	Inserir(&l, 4);
	Avancar(&l);
	Actual(l, &p);
	if (p != 4)
		b = false;
	if (b == true)
	{
		printf("Funcions Inserir i Avancar funcionen correctament\n");

	}
	
	b = true;
	Retrocedir(&l);
	Actual(l, &p);
	if (p != 3)
		b = false;
	if (b == true)
	{
		printf("Funcio Retrocedir funciona correctament\n");

	}

	b = false;
	Avancar(&l);
	Es_Final(l, &b);
	if (b == true)
	{
		printf("Funcio Es_Final funciona correctament\n");

	}
	

	b = true;
	Principi(&l);
	Actual(l, &p);
	if (p != 1)
		b = false;
	if (b == true)
	{
		printf("Funcio Principi funciona correctament\n");

	}

	b = true;
	Final(&l);
	Actual(l, &p);
	if (p != 4)
		b = false;
	if (b == true)
	{
		printf("Funcio Final funciona correctament\n");

	}

	b = true;
	Esborrar(&l);
	Actual(l, &p);
	if (p != 3)
		b = false;
	Retrocedir(&l);
	Esborrar(&l);
	Actual(l, &p);
	if (p != 3)
		b = false;
	Retrocedir(&l);
	Esborrar(&l);
	Actual(l, &p);
	if (p != 3)
		b = false;
	if (b == true)
		printf("3 proves de la funcio Esborrar, funciona correctament\n");

	b = true;
	Longitud(l, &p);
	if (p != 1)
		b = false;
	Inserir(&l, 4);
	Avancar(&l);
	Inserir(&l, 5);
	Avancar(&l);
	Inserir(&l, 6);
	Avancar(&l);
	Inserir(&l, 7);
	Avancar(&l);
	Inserir(&l, 8);
	Avancar(&l);
	Inserir(&l, 9);
	Avancar(&l);
	Inserir(&l, 10);
	Avancar(&l);
	Inserir(&l, 11);
	Longitud(l, &p);
	if (p != 9)
		b = false;
	Avancar(&l);
	Esborrar(&l);
	Longitud(l, &p);
	if (p != 8)
		b = false;
	if (b == true)
	{
		printf("3 proves de la funcio Longitud, funciona correctament\n");
	}

	b = true;
	busca = false;
	Buscar(l, 9, &busca);
	if (busca == false)
		b = false;
	Buscar(l, 64, &busca);
	if (busca == true)
		b = false;
	Buscar(l, 4, &busca);
	if (busca == false)
		b = false;
	if (b == true)
	{
		printf("3 proves de la funcio Buscar, funciona correctament\n");
	}
	
	b = true;
	Cost_Buscar(l, 3, &p);
	if (p != 1)
		b = false;
	Cost_Buscar(l, 10, &p);
	if (p != 8)
		b = false;
	Cost_Buscar(l, 64, &p);
	if (p != 9)
		b = false;
	if (b == true)
	{
		printf("3 proves de la funcio Cost_Buscar, funciona correctament\n");
	}

	node * n;
	n = (node*)malloc(sizeof(node));
	n = l.pdi;
	Destruir(&l);
	if(n->element!=10)
		printf("1 prova de la funcio Destruir, funciona correctament\n");

	//GENERACI� DE LLISTES AMB NUMEROS ALEATORIS:
	printf("\nPassem ara a generar un fitxer csv amb el resultat de cerques de numeros aleatoris:\n");
	
	FILE* fp;
	fp= fopen("resultados.csv", "w+");
	llista_encadenada * llista;
	char frase[20] = "hola";
	long sem=0, sem2=0;
	phrtsd(frase, &sem, &sem2);
	setall(sem, sem2);
	int cost,costtotal=0;
	long num;
	long largest,temparray[1000];
	fprintf(fp, "Mida de la llista,Cost mitja,Desviacio estandar");
	for (int j = 1; j <= 50; j++)
	{
		llista = (llista_encadenada*)malloc(sizeof(llista_encadenada));
		Crear(llista);
		for (int k = 0;  k < j * 1000; k++)
		{
			Inserir(llista, ignuin(1, j * 2000));
			Avancar(llista);
		}
		for (int i = 0; i < 1000; i++)
		{
			Cost_Buscar(*llista, ignuin(1, j * 2000), &cost);
			costtotal = costtotal + cost;
			temparray[i] = cost;
		}
		costtotal = costtotal / 1000;
		for (int i = 0; i < 1000; i++)
		{
			d = d + (((temparray[i] - costtotal) * (temparray[i] - costtotal))/1000);
		}
		d = sqrt(d);
		fprintf(fp, "\n%d,%d,%d", j * 1000, costtotal, d);
		d = 0;
		free(llista);
		printf("%d ", j);
	}
	fclose(fp);

}
